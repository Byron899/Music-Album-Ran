# Music Album Ranking App
Frontend for a music album ranking tool built in React.
